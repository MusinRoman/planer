<?php
session_start(); // Начинаем сессию

require_once 'db_connect.php'; // Подключаем файл с подключением к БД

$message = ''; // Переменная для сообщений пользователю

// Проверяем, авторизован ли пользователь и является ли он администратором
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    // Если нет, перенаправляем на страницу входа
    header("Location: admin_login.php");
    exit();
}

$current_username = $_SESSION['username']; // Имя текущего администратора
$admin_department = $_SESSION['department'] ?? null; // Отдел текущего администратора

// Если отдел администратора не установлен в сессии, получаем его из БД
if ($admin_department === null) {
    $stmt_department = $conn->prepare("SELECT department FROM users WHERE id = ?");
    $stmt_department->bind_param("i", $_SESSION['user_id']);
    $stmt_department->execute();
    $result_department = $stmt_department->get_result();
    if ($row_department = $result_department->fetch_assoc()) {
        $_SESSION['department'] = $row_department['department'];
        $admin_department = $row_department['department'];
    }
    $stmt_department->close();
}

// Обработка выхода
if (isset($_GET['logout'])) {
    session_destroy(); // Удаляем все данные сессии
    header("Location: admin_login.php"); // Перенаправляем на страницу входа
    exit();
}

// Обработка фильтрации задач по пользователю
$filter_user_id = null;
if (isset($_GET['filter_user'])) {
    $filter_user_id = (int)$_GET['filter_user'];
    if ($filter_user_id === 0) { // Если выбрано "Все задачи", сбрасываем фильтр
        $filter_user_id = null;
    }
}


// Обработка действий администратора
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_task'])) {
        $task_id = $_POST['task_id'];
        $new_status = $_POST['new_status'];
        $new_admin_due_date = $_POST['new_admin_due_date'];

        // Добавим проверку, что администратор обновляет задачу своего отдела
        $stmt_check_department = $conn->prepare("SELECT department FROM tasks WHERE id = ?");
        $stmt_check_department->bind_param("i", $task_id);
        $stmt_check_department->execute();
        $result_check_department = $stmt_check_department->get_result();
        $task_department_row = $result_check_department->fetch_assoc();
        $stmt_check_department->close();

        if ($task_department_row && $task_department_row['department'] === $admin_department) {
            // Преобразование даты из dd-mm-yy в YYYY-MM-DD для БД
            $formatted_admin_due_date = NULL;
            if (!empty($new_admin_due_date)) {
                $date_obj = DateTime::createFromFormat('d-m-Y', $new_admin_due_date);
                if ($date_obj) {
                    $formatted_admin_due_date = $date_obj->format('Y-m-d');
                } else {
                    $_SESSION['message'] = "<p style='color: red;'>Неверный формат даты. Используйте ДД-ММ-ГГГГ.</p>";
                    $formatted_admin_due_date = NULL;
                }
            }

            // Обновляем задачу. admin_comment УДАЛЕН из запроса
            $stmt = $conn->prepare("UPDATE tasks SET status = ?, admin_due_date = ? WHERE id = ?");
            $stmt->bind_param("ssi", $new_status, $formatted_admin_due_date, $task_id);

            if ($stmt->execute()) {
                $_SESSION['message'] = "<p style='color: green;'>Задача успешно обновлена!</p>";
            } else {
                $_SESSION['message'] = "<p style='color: red;'>Ошибка при обновлении задачи: " . $stmt->error . "</p>";
            }
            $stmt->close();
        } else {
            $_SESSION['message'] = "<p style='color: red;'>У вас нет прав для обновления этой задачи.</p>";
        }
    } elseif (isset($_POST['archive_task_admin'])) {
        $task_id = $_POST['task_id'];

        // Проверяем, что администратор архивирует задачу своего отдела
        $stmt_check_department = $conn->prepare("SELECT department FROM tasks WHERE id = ?");
        $stmt_check_department->bind_param("i", $task_id);
        $stmt_check_department->execute();
        $result_check_department = $stmt_check_department->get_result();
        $task_department_row = $result_check_department->fetch_assoc();
        $stmt_check_department->close();

        if ($task_department_row && $task_department_row['department'] === $admin_department) {
            $stmt_archive = $conn->prepare("UPDATE tasks SET is_archived = 1 WHERE id = ?");
            $stmt_archive->bind_param("i", $task_id);

            if ($stmt_archive->execute()) {
                $_SESSION['message'] = "<p style='color: green;'>Задача успешно заархивирована!</p>";
            } else {
                $_SESSION['message'] = "<p style='color: red;'>Ошибка при архивировании задачи: " . $stmt_archive->error . "</p>";
            }
            $stmt_archive->close();
        } else {
            $_SESSION['message'] = "<p style='color: red;'>У вас нет прав для архивирования этой задачи.</p>";
        }
    } elseif (isset($_POST['restore_task'])) {
        $task_id = $_POST['task_id'];
        $stmt_check_department = $conn->prepare("SELECT department FROM tasks WHERE id = ?");
        $stmt_check_department->bind_param("i", $task_id);
        $stmt_check_department->execute();
        $result_check_department = $stmt_check_department->get_result();
        $task_department_row = $result_check_department->fetch_assoc();
        $stmt_check_department->close();

        if ($task_department_row && $task_department_row['department'] === $admin_department) {
            $stmt_restore = $conn->prepare("UPDATE tasks SET is_archived = 0 WHERE id = ?");
            $stmt_restore->bind_param("i", $task_id);

            if ($stmt_restore->execute()) {
                $_SESSION['message'] = "<p style='color: green;'>Задача успешно восстановлена из архива!</p>";
            } else {
                $_SESSION['message'] = "<p style='color: red;'>Ошибка при восстановлении задачи из архива: " . $stmt_restore->error . "</p>";
            }
            $stmt_restore->close();
        } else {
            $_SESSION['message'] = "<p style='color: red;'>У вас нет прав для восстановления этой задачи.</p>";
        }
    } elseif (isset($_POST['delete_archived_task'])) {
        $task_id = $_POST['task_id'];

        $stmt_check_department = $conn->prepare("SELECT department FROM tasks WHERE id = ?");
        $stmt_check_department->bind_param("i", $task_id);
        $stmt_check_department->execute();
        $result_check_department = $stmt_check_department->get_result();
        $task_department_row = $result_check_department->fetch_assoc();
        $stmt_check_department->close();

        if ($task_department_row && $task_department_row['department'] === $admin_department) {
            $conn->begin_transaction();
            try {
                // --- НАЧАЛО: Удаление связанных файлов задачи ---
                $stmt_get_files = $conn->prepare("SELECT file_paths FROM tasks WHERE id = ?");
                $stmt_get_files->bind_param("i", $task_id);
                $stmt_get_files->execute();
                $result_files = $stmt_get_files->get_result();
                $file_paths_row = $result_files->fetch_assoc();
                $stmt_get_files->close();

                if ($file_paths_row && !empty($file_paths_row['file_paths'])) {
                    $files_to_delete = json_decode($file_paths_row['file_paths'], true);
                    if (is_array($files_to_delete)) {
                        foreach ($files_to_delete as $file_path) {
                            $full_file_path = __DIR__ . '/../' . $file_path; // Путь к файлу
                            if (file_exists($full_file_path)) {
                                if (!unlink($full_file_path)) {
                                    error_log("Не удалось удалить файл задачи: " . $full_file_path);
                                }
                            } else {
                                error_log("Файл задачи не существует при попытке удаления: " . $full_file_path);
                            }
                        }
                    }
                }
                // --- КОНЕЦ: Удаление связанных файлов задачи ---

                // --- НАЧАЛО: Удаление файлов из сообщений чата, связанных с этой задачей ---
                // ДОБАВЛЕНО: Выбираем только те файлы, которые действительно являются файлами (не пустые строки)
                $stmt_get_chat_files = $conn->prepare("SELECT file_path FROM task_messages WHERE task_id = ? AND file_path IS NOT NULL AND file_path != ''");
                $stmt_get_chat_files->bind_param("i", $task_id);
                $stmt_get_chat_files->execute();
                $result_chat_files = $stmt_get_chat_files->get_result();
                $chat_files_to_delete = [];
                while ($row = $result_chat_files->fetch_assoc()) {
                    if ($row['file_path']) {
                        // Декодируем JSON, так как file_path может содержать массив
                        $decoded_paths = json_decode($row['file_path'], true);
                        if (is_array($decoded_paths)) {
                            $chat_files_to_delete = array_merge($chat_files_to_delete, $decoded_paths);
                        }
                    }
                }
                $stmt_get_chat_files->close();
                foreach ($chat_files_to_delete as $path) {
                    $full_chat_file_path = __DIR__ . '/../' . $path; // Убеждаемся, что путь корректен
                    if (file_exists($full_chat_file_path)) {
                        if (unlink($full_chat_file_path)) {
                            error_log("Удален файл сообщения при удалении задачи из архива: " . $full_chat_file_path);
                        } else {
                            error_log("Не удалось удалить файл сообщения при удалении задачи из архива: " . $full_chat_file_path);
                        }
                    } else {
                        error_log("Файл сообщения не найден при удалении задачи из архива: " . $full_chat_file_path);
                    }
                }
                // --- КОНЕЦ: Удаление файлов из сообщений чата ---

                // Удаляем связанные сообщения
                $stmt_delete_messages = $conn->prepare("DELETE FROM task_messages WHERE task_id = ?");
                $stmt_delete_messages->bind_param("i", $task_id);
                $stmt_delete_messages->execute();
                $stmt_delete_messages->close();

                // Удаляем саму задачу
                $stmt_delete_task = $conn->prepare("DELETE FROM tasks WHERE id = ?");
                $stmt_delete_task->bind_param("i", $task_id);
                $stmt_delete_task->execute();
                $stmt_delete_task->close();

                $conn->commit();
                $_SESSION['message'] = "<p style='color: green;'>Архивная задача и связанные данные успешно удалены!</p>";
            } catch (mysqli_sql_exception $e) {
                $conn->rollback();
                $_SESSION['message'] = "<p style='color: red;'>Ошибка при удалении архивной задачи: " . $e->getMessage() . "</p>";
            }
        } else {
            $_SESSION['message'] = "<p style='color: red;'>У вас нет прав для удаления этой архивной задачи.</p>";
        }
    } elseif (isset($_POST['clear_all_archive'])) {
        // УДАЛЕНИЕ ВСЕХ АРХИВНЫХ ЗАДАЧ
        $conn->begin_transaction();
        try {
            // Получаем список task_id и file_paths всех архивных задач для текущего отдела
            $stmt_get_archived_data = $conn->prepare("SELECT id, file_paths FROM tasks WHERE is_archived = 1 AND department = ?");
            $stmt_get_archived_data->bind_param("s", $admin_department);
            $stmt_get_archived_data->execute();
            $result_archived_data = $stmt_get_archived_data->get_result();
            $archived_task_ids = [];
            $all_task_files_to_delete = [];

            while ($row = $result_archived_data->fetch_assoc()) {
                $archived_task_ids[] = $row['id'];
                if (!empty($row['file_paths'])) {
                    $files = json_decode($row['file_paths'], true);
                    if (is_array($files)) {
                        $all_task_files_to_delete = array_merge($all_task_files_to_delete, $files);
                    }
                }
            }
            $stmt_get_archived_data->close();

            // --- НАЧАЛО: Удаление всех связанных файлов задач для очищаемого архива ---
            foreach ($all_task_files_to_delete as $file_path) {
                $full_file_path = __DIR__ . '/../' . $file_path; // Путь к файлу
                if (file_exists($full_file_path)) {
                    if (!unlink($full_file_path)) {
                        error_log("Не удалось удалить файл задачи при очистке архива: " . $full_file_path);
                    }
                } else {
                        error_log("Файл задачи не существует при попытке очистки архива: " . $full_file_path);
                }
            }
            // --- КОНЕЦ: Удаление всех связанных файлов задач для очищаемого архива ---

            if (!empty($archived_task_ids)) {
                $in_clause = implode(',', array_fill(0, count($archived_task_ids), '?'));
                $types = str_repeat('i', count($archived_task_ids));

                // --- НАЧАЛО: Удаление файлов из сообщений чата, связанных с архивными задачами ---
                // ДОБАВЛЕНО: Выбираем только те файлы, которые действительно являются файлами (не пустые строки)
                $stmt_get_chat_files_batch = $conn->prepare("SELECT file_path FROM task_messages WHERE task_id IN ($in_clause) AND file_path IS NOT NULL AND file_path != ''");
                $stmt_get_chat_files_batch->bind_param($types, ...$archived_task_ids);
                $stmt_get_chat_files_batch->execute();
                $result_chat_files_batch = $stmt_get_chat_files_batch->get_result();
                $all_chat_files_to_delete = [];
                while ($chat_file_row_batch = $result_chat_files_batch->fetch_assoc()) {
                    // Декодируем JSON, так как file_path может содержать массив
                    $decoded_chat_paths = json_decode($chat_file_row_batch['file_path'], true);
                    if (is_array($decoded_chat_paths)) {
                        $all_chat_files_to_delete = array_merge($all_chat_files_to_delete, $decoded_chat_paths);
                    }
                }
                $stmt_get_chat_files_batch->close();

                foreach ($all_chat_files_to_delete as $path) {
                    $full_chat_file_path_batch = __DIR__ . '/../' . $path; // Убеждаемся, что путь корректен
                    if (file_exists($full_chat_file_path_batch)) {
                        if (!unlink($full_chat_file_path_batch)) {
                            error_log("Не удалось удалить файл чата при очистке архива: " . $full_chat_file_path_batch);
                        }
                    } else {
                        error_log("Файл чата не существует при попытке очистки архива: " . $full_chat_file_path_batch);
                    }
                }
                // --- КОНЕЦ: Удаление файлов из сообщений чата ---

            // Удаляем сообщения, связанные с этими задачами
                $stmt_delete_messages_batch = $conn->prepare("DELETE FROM task_messages WHERE task_id IN ($in_clause)");
                $stmt_delete_messages_batch->bind_param($types, ...$archived_task_ids);
                $stmt_delete_messages_batch->execute();
                $stmt_delete_messages_batch->close();
            }

            // Удаляем сами архивные задачи для текущего отдела
            $stmt_clear_archive = $conn->prepare("DELETE FROM tasks WHERE is_archived = 1 AND department = ?");
            $stmt_clear_archive->bind_param("s", $admin_department);

            if ($stmt_clear_archive->execute()) {
                $conn->commit();
                $_SESSION['message'] = "<p style='color: green;'>Весь архив задач для вашего отдела успешно очищен!</p>";
            } else {
                $conn->rollback();
                $_SESSION['message'] = "<p style='color: red;'>Ошибка при очистке архива: " . $stmt_clear_archive->error . "</p>";
            }
            $stmt_clear_archive->close();
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $_SESSION['message'] = "<p style='color: red;'>Ошибка при очистке архива: " . $e->getMessage() . "</p>";
        }
    }
    elseif (isset($_POST['confirm_user'])) {
        // Только 'admingg' может подтверждать пользователей
        if ($current_username !== 'admingg') {
            $_SESSION['message'] = "<p style='color: red;'>У вас нет прав для подтверждения пользователей.</p>";
            header("Location: admin.php?tab=" . ($_GET['tab'] ?? 'active-tasks') . (isset($_GET['filter_user']) ? '&filter_user=' . $_GET['filter_user'] : ''));
            exit();
        }

        $user_id_to_confirm = $_POST['user_id'];
        $make_admin = isset($_POST['make_admin']) ? 1 : 0; // Получаем значение чекбокса

        // Обновляем пользователя: подтверждаем и опционально делаем администратором
        $stmt_confirm = $conn->prepare("UPDATE users SET is_confirmed = TRUE, is_admin = ? WHERE id = ?");
        $stmt_confirm->bind_param("ii", $make_admin, $user_id_to_confirm);

        if ($stmt_confirm->execute()) {
            $_SESSION['message'] = "<p style='color: green;'>Пользователь успешно подтвержден!" . ($make_admin ? " И назначен администратором." : "") . "</p>";
        } else {
            $_SESSION['message'] = "<p style='color: red;'>Ошибка при подтверждении пользователя: " . $stmt_confirm->error . "</p>";
        }
        $stmt_confirm->close();
    } elseif (isset($_POST['delete_unconfirmed_user'])) {
        // Только 'admingg' может удалять неподтвержденных пользователей
        if ($current_username !== 'admingg') {
            $_SESSION['message'] = "<p style='color: red;'>У вас нет прав для удаления неподтвержденных пользователей.</p>";
            header("Location: admin.php?tab=" . ($_GET['tab'] ?? 'active-tasks') . (isset($_GET['filter_user']) ? '&filter_user=' . $_GET['filter_user'] : ''));
            exit();
        }

        $user_id_to_delete = $_POST['user_id'];

        // Удаление неподтвержденного пользователя, связанных с ним задач и комментариев
        $conn->begin_transaction();
        try {
            // Получаем список task_id и file_paths всех задач, созданных этим пользователем
            $stmt_get_user_tasks_files = $conn->prepare("SELECT id, file_paths FROM tasks WHERE user_id = ?");
            $stmt_get_user_tasks_files->bind_param("i", $user_id_to_delete);
            $stmt_get_user_tasks_files->execute();
            $result_user_tasks_files = $stmt_get_user_tasks_files->get_result();
            $user_task_ids = [];
            $user_task_files_to_delete = [];

            while ($row = $result_user_tasks_files->fetch_assoc()) {
                $user_task_ids[] = $row['id'];
                if (!empty($row['file_paths'])) {
                    $files = json_decode($row['file_paths'], true);
                    if (is_array($files)) {
                        $user_task_files_to_delete = array_merge($user_task_files_to_delete, $files);
                    }
                }
            }
            $stmt_get_user_tasks_files->close();

            // --- НАЧАЛО: Удаление файлов, связанных с задачами пользователя ---
            foreach ($user_task_files_to_delete as $file_path) {
                $full_file_path = __DIR__ . '/../' . $file_path; // Путь к файлу
                if (file_exists($full_file_path)) {
                    if (!unlink($full_file_path)) {
                        error_log("Не удалось удалить файл задачи пользователя при удалении: " . $full_file_path);
                    }
                } else {
                    error_log("Файл задачи пользователя не существует при попытке удаления: " . $full_file_path);
                }
            }
            // --- КОНЕЦ: Удаление файлов, связанных с задачами пользователя ---

            if (!empty($user_task_ids)) {
                $in_clause_tasks = implode(',', array_fill(0, count($user_task_ids), '?'));
                $types_tasks = str_repeat('i', count($user_task_ids));

                // --- НАЧАЛО: Удаление файлов из сообщений чата, связанных с задачами пользователя ---
                // ДОБАВЛЕНО: Выбираем только те файлы, которые действительно являются файлами (не пустые строки)
                $stmt_get_chat_files_user = $conn->prepare("SELECT file_path FROM task_messages WHERE task_id IN ($in_clause_tasks) AND file_path IS NOT NULL AND file_path != ''");
                $stmt_get_chat_files_user->bind_param($types_tasks, ...$user_task_ids);
                $stmt_get_chat_files_user->execute();
                $result_chat_files_user = $stmt_get_chat_files_user->get_result();
                $all_chat_files_user_to_delete = [];
                while ($chat_file_row_user = $result_chat_files_user->fetch_assoc()) {
                    // Декодируем JSON, так как file_path может содержать массив
                    $decoded_user_chat_paths = json_decode($chat_file_row_user['file_path'], true);
                    if (is_array($decoded_user_chat_paths)) {
                        $all_chat_files_user_to_delete = array_merge($all_chat_files_user_to_delete, $decoded_user_chat_paths);
                    }
                }
                $stmt_get_chat_files_user->close();

                foreach ($all_chat_files_user_to_delete as $path) {
                    $full_chat_file_path_user = __DIR__ . '/../' . $path; // Убеждаемся, что путь корректен
                    if (file_exists($full_chat_file_path_user)) {
                        if (!unlink($full_chat_file_path_user)) {
                            error_log("Не удалось удалить файл чата пользователя при удалении: " . $full_chat_file_path_user);
                        }
                    } else {
                        error_log("Файл чата пользователя не существует при попытке удаления: " . $full_chat_file_path_user);
                    }
                }
                // --- КОНЕЦ: Удаление файлов из сообщений чата ---

                // Удаляем сообщения, связанные с задачами пользователя
                $stmt_delete_messages = $conn->prepare("DELETE FROM task_messages WHERE task_id IN ($in_clause_tasks)");
                $stmt_delete_messages->bind_param($types_tasks, ...$user_task_ids);
                $stmt_delete_messages->execute();
                $stmt_delete_messages->close();
            }

            // Удаляем задачи, созданные этим пользователем
            $stmt_delete_tasks = $conn->prepare("DELETE FROM tasks WHERE user_id = ?");
            $stmt_delete_tasks->bind_param("i", $user_id_to_delete);
            $stmt_delete_tasks->execute();
            $stmt_delete_tasks->close();

            // Удаляем комментарии, созданные этим пользователем (если есть комментарии не связанные с задачей)
            // Примечание: Если все комментарии строго привязаны к задачам, и задачи уже удалены,
            // этот запрос может быть избыточным, но для надежности его можно оставить.
            $stmt_delete_messages_by_user = $conn->prepare("DELETE FROM task_messages WHERE sender_id = ?");
            $stmt_delete_messages_by_user->bind_param("i", $user_id_to_delete);
            $stmt_delete_messages_by_user->execute();
            $stmt_delete_messages_by_user->close();

            // И наконец, удаляем самого пользователя
            $stmt_delete_user = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt_delete_user->bind_param("i", $user_id_to_delete);
            $stmt_delete_user->execute();
            $stmt_delete_user->close();

            $conn->commit();
            $_SESSION['message'] = "<p style='color: green;'>Неподтвержденный пользователь и все связанные данные успешно удалены!</p>";
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $_SESSION['message'] = "<p style='color: red;'>Ошибка при удалении пользователя: " . $e->getMessage() . "</p>";
        }
    }
    header("Location: admin.php?tab=" . ($_GET['tab'] ?? 'active-tasks') . (isset($_GET['filter_user']) ? '&filter_user=' . $_GET['filter_user'] : ''));
    exit();
}

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Удаляем сообщение из сессии, чтобы оно не отображалось повторно
}


// Массив для сопоставления русских статусов с CSS-классами (независимо от языка)
$status_class_map = [
    'На удержании' => 'na_uderzhanii',
    'Задача принята' => 'zadacha_prinyata',
    'Исполняется' => 'ispolnyaetsya',
    'Выполнена' => 'vypolnena'
];

/**
 * Генерирует HTML для списка активных задач администратора.
 * @param mysqli $conn Объект подключения к базе данных.
 * @param string $admin_department Отдел текущего администратора.
 * @param int|null $filter_user_id ID пользователя для фильтрации.
 * @param array $status_class_map Массив сопоставления статусов.
 * @return string HTML-строка со списком задач.
 */
function getAdminActiveTasksHtml($conn, $admin_department, $filter_user_id, $status_class_map) {
    ob_start(); // Начинаем буферизацию вывода
    ?>
    <h2>Активные задачи</h2>
    <div style="margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
        <form action="admin.php" method="get" style="margin: 0; display: block; align-items: center; gap: 10px;">
            <label for="filter_user">Фильтр по ресторану:</label>
            <select name="filter_user" id="filter_user" style="width: auto;">
                <option value="0">Все задачи</option>
                <?php
                // Получаем список всех зарегистрированных пользователей, кроме администраторов
                $sql_users = "SELECT id, username FROM users WHERE is_admin = FALSE ORDER BY username ASC";
                $result_users = $conn->query($sql_users);

                if ($result_users) {
                    while ($user = $result_users->fetch_assoc()) {
                        $selected = ($filter_user_id == $user['id']) ? 'selected' : '';
                        echo "<option value='" . htmlspecialchars($user['id']) . "' " . $selected . ">" . htmlspecialchars($user['username']) . "</option>";
                    }
                } else {
                    echo "<option value=''>Ошибка загрузки пользователей</option>";
                }
                ?>
            </select>
            <button type="submit">Применить</button>
            <input type="hidden" name="tab" value="active-tasks">
        </form>
    </div>
    <div class="list-container tasks">
        <?php
        $sql = "SELECT t.id, t.task_description, t.desired_due_date, t.admin_due_date, t.status, t.created_at, u.username, t.department, t.file_paths
                        FROM tasks t
                        LEFT JOIN users u ON t.user_id = u.id
                        WHERE t.department = ? AND t.is_archived = 0";

        if ($filter_user_id !== null) {
            $sql .= " AND t.user_id = ?";
        }

        $sql .= " ORDER BY t.created_at DESC";

        $stmt = $conn->prepare($sql);

        if ($filter_user_id !== null) {
            $stmt->bind_param("si", $admin_department, $filter_user_id);
        } else {
            $stmt->bind_param("s", $admin_department);
        }

        $stmt->execute();
        $result = $stmt->get_result();

        // Получаем количество непрочитанных сообщений
        $unread_messages_count = [];
        $stmt_unread = $conn->prepare("
            SELECT tm.task_id, COUNT(tm.id) AS unread_count FROM task_messages tm
            JOIN users sender ON tm.sender_id = sender.id
            JOIN tasks t ON tm.task_id = t.id
            WHERE tm.is_read = 0
            AND sender.is_admin = 0
            AND t.is_archived = 0
            AND t.department = ?
            GROUP BY tm.task_id
        ");
        $stmt_unread->bind_param("s", $admin_department);
        $stmt_unread->execute();
        $result_unread = $stmt_unread->get_result();
        while ($unread_row = $result_unread->fetch_assoc()) {
            $unread_messages_count[$unread_row['task_id']] = $unread_row['unread_count'];
        }
        $stmt_unread->close();


        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $status_css_class = $status_class_map[$row["status"]] ?? 'unknown_status';

                echo "<div class='table-list-row'> <div class='list-row'> ";
                echo "<div class='list-cell date'><strong>Жел. срок:</strong><br class='display'> " . ($row["desired_due_date"] ? htmlspecialchars(date('d-m-Y', strtotime($row["desired_due_date"]))) : "Не указан") . "</div>";

                echo "<div class='list-cell date'>";
                echo "<form action='admin.php' method='post' style='margin:0;'>";
                echo "<input type='hidden' name='task_id' value='" . htmlspecialchars($row["id"]) . "'>";
                if ($filter_user_id !== null) {
                    echo "<input type='hidden' name='filter_user' value='" . htmlspecialchars($filter_user_id) . "'>";
                }
                echo "<input type='hidden' name='tab' value='active-tasks'>"; // Для сохранения вкладки после POST
                echo "<strong>Срок исполнения:</strong><br class='display'>";
                $display_admin_due_date = $row["admin_due_date"] ? htmlspecialchars(date('d-m-Y', strtotime($row["admin_due_date"]))) : "";
                echo "<input type='text' class='datepicker' name='new_admin_due_date' value='" . $display_admin_due_date . "'>";
                echo "</div>";

                echo "<div class='list-cell status " . $status_css_class . "'>";
                echo "<strong>Статус:</strong><br class='display'> <select name='new_status'>";
                $statuses = ['На удержании', 'Задача принята', 'Исполняется', 'Выполнена'];
                foreach ($statuses as $status) {
                    echo "<option value='" . htmlspecialchars($status) . "'" . ($row["status"] == $status ? " selected" : "") . ">" . htmlspecialchars($status) . "</option>";
                }
                echo "</select>";
                echo "</div>";

                echo "<div class='list-cell restaurant'><strong>Ресторан:</strong><br class='display'> " . htmlspecialchars($row["username"] ? $row["username"] : "Неизвестно") . "</div>";
                echo "<div class='list-cell created_at'><strong>Дата создания:</strong><br class='display'> " . htmlspecialchars(date('d-m-Y', strtotime($row["created_at"]))) . "</div>";


                echo "<div class='list-cell actions'>";
                echo "<button type='submit' name='update_task'>Обновить</button>";
                echo "</form>";
                $task_id_chat = htmlspecialchars($row['id']);
                $has_new_messages = isset($unread_messages_count[$task_id_chat]) && $unread_messages_count[$task_id_chat] > 0;
                echo "<a href='/chat.php?task_id=" . $task_id_chat . "' class='edit-button chat-button'>";
                echo "Переписка";
                if ($has_new_messages) {
                    echo "<span class='new-message-indicator'></span>";
                }
                echo "</a>";


                echo "<form action='admin.php' method='post' style='margin:0;' onsubmit=\"return confirm('Вы уверены, что хотите заархивировать эту задачу?');\">";
                echo "<input type='hidden' name='task_id' value='" . htmlspecialchars($row['id']) . "'>";
                if ($filter_user_id !== null) {
                    echo "<input type='hidden' name='filter_user' value='" . htmlspecialchars($filter_user_id) . "'>";
                }
                 echo "<input type='hidden' name='tab' value='active-tasks'>"; // Для сохранения вкладки после POST
                echo "<button type='submit' name='archive_task_admin' class='archive-button-admin'>Архивировать</button>";
                echo "</form>";
                echo "</div>";
                echo "</div>";

                echo "<div class='list-cell description'><strong>Описание задачи:</strong><br> " . nl2br(htmlspecialchars($row["task_description"]));
                if (!empty($row['file_paths'])) {
                    $files = json_decode($row['file_paths'], true);
                    if (is_array($files) && count($files) > 0) {
                        echo "<br><strong>Прикрепленные файлы:</strong><br>";
                        $file_counter = 1;
                        foreach ($files as $file_path) {
                            echo "<a href='/" . htmlspecialchars($file_path) . "' target='_blank'>Файл " . $file_counter . "</a><br>";
                            $file_counter++;
                        }
                    }
                }
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='list-row'><div class='list-cell' style='width: 100%;'>Активных задач для вашего отдела пока нет.";
            if ($filter_user_id !== null) {
                echo " Или у выбранного пользователя нет задач.";
            }
            echo "</div></div>";
        }
        $stmt->close();
        ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Генерирует HTML для списка новых регистраций.
 * @param mysqli $conn Объект подключения к базе данных.
 * @param int|null $filter_user_id ID пользователя для фильтрации (для сохранения фильтра при POST-запросах).
 * @return string HTML-строка со списком пользователей.
 */
function getNewRegistrationsHtml($conn, $filter_user_id) {
    ob_start();
    ?>
    <h2>Новые регистрации (ожидают подтверждения)</h2>
    <div class="list-container users">
        <?php
        $sql_unconfirmed_users = "SELECT id, username, created_at FROM users WHERE is_confirmed = FALSE ORDER BY created_at ASC";
        $result_unconfirmed_users = $conn->query($sql_unconfirmed_users);

        if ($result_unconfirmed_users->num_rows > 0) {
            while($user_row = $result_unconfirmed_users->fetch_assoc()) {
                echo "<div class='list-row'>";
                echo "<div class='list-cell id'><strong>ID:</strong><br> " . htmlspecialchars($user_row["id"]) . "</div>";
                echo "<div class='list-cell username'><strong>Имя пользователя:</strong><br> " . htmlspecialchars($user_row["username"]) . "</div>";
                echo "<div class='list-cell created_at'><strong>Дата регистрации:</strong><br> " . htmlspecialchars(date('d-m-Y', strtotime($user_row["created_at"]))) . "</div>";
                echo "<div class='list-cell actions'>";
                echo "<form action='admin.php' method='post' style='margin:0;'>";
                echo "<input type='hidden' name='user_id' value='" . htmlspecialchars($user_row["id"]) . "'";
                if ($filter_user_id !== null) {
                    echo "><input type='hidden' name='filter_user' value='" . htmlspecialchars($filter_user_id) . "'";
                }
                echo "><input type='hidden' name='tab' value='new-registrations'>";
                echo "<label><input type='checkbox' name='make_admin' value='1'> Сделать администратором</label>"; // Чекбокс
                echo "<button type='submit' name='confirm_user' style='background-color: #28a745;'>Подтвердить</button>";
                echo "</form>";
                echo "<form action='admin.php' method='post' style='margin:0;' onsubmit=\"return confirm('Вы уверены, что хотите удалить этого пользователя? Это действие необратимо.');\">";
                echo "<input type='hidden' name='user_id' value='" . htmlspecialchars($user_row["id"]) . "'";
                if ($filter_user_id !== null) {
                    echo "><input type='hidden' name='filter_user' value='" . htmlspecialchars($filter_user_id) . "'";
                }
                echo "><input type='hidden' name='tab' value='new-registrations'>";
                echo "<button type='submit' name='delete_unconfirmed_user' style='background-color: #dc3545;'>Удалить</button>";
                echo "</form>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='list-row'><div class='list-cell' style='width: 100%;'>Новых пользователей для подтверждения нет.</div></div>";
        }
        ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Генерирует HTML для списка архивных задач администратора.
 * @param mysqli $conn Объект подключения к базе данных.
 * @param string $admin_department Отдел текущего администратора.
 * @param int|null $filter_user_id ID пользователя для фильтрации.
 * @param array $status_class_map Массив сопоставления статусов.
 * @return string HTML-строка со списком задач.
 */
function getAdminArchivedTasksHtml($conn, $admin_department, $filter_user_id, $status_class_map) {
    ob_start();
    ?>
    <h2>Архив задач</h2>
    <div style="margin-bottom: 20px;">
        <form action="admin.php" method="post" onsubmit="return confirm('Вы уверены, что хотите полностью очистить архив задач для вашего отдела? Это действие необратимо!');">
            <button type="submit" name="clear_all_archive" class="clear-all-archive-button">Очистить весь архив для моего отдела</button>
            <input type="hidden" name="tab" value="archived-tasks">
        </form>
    </div>

    <div class="list-container archive-tasks">
        <?php
        $sql_archived = "SELECT t.id, t.task_description, t.desired_due_date, t.admin_due_date, t.status, t.created_at, u.username, t.department, t.file_paths
                            FROM tasks t
                            LEFT JOIN users u ON t.user_id = u.id
                            WHERE t.is_archived = 1 AND t.department = ?";

        if ($filter_user_id !== null) {
            $sql_archived .= " AND t.user_id = ?";
        }

        $sql_archived .= " ORDER BY t.created_at DESC";

        $stmt_archived = $conn->prepare($sql_archived);

        if ($filter_user_id !== null) {
            $stmt_archived->bind_param("si", $admin_department, $filter_user_id);
        } else {
            $stmt_archived->bind_param("s", $admin_department);
        }

        $stmt_archived->execute();
        $result_archived = $stmt_archived->get_result();

         // Получаем количество непрочитанных сообщений для архивных задач
        $unread_messages_count_archive = [];
        $stmt_unread_archive = $conn->prepare("
            SELECT tm.task_id, COUNT(tm.id) AS unread_count FROM task_messages tm
            JOIN users sender ON tm.sender_id = sender.id
            JOIN tasks t ON tm.task_id = t.id
            WHERE tm.is_read = 0
            AND sender.is_admin = 0
            AND t.is_archived = 1
            AND t.department = ?
            GROUP BY tm.task_id
        ");
        $stmt_unread_archive->bind_param("s", $admin_department);
        $stmt_unread_archive->execute();
        $result_unread_archive = $stmt_unread_archive->get_result();
        while ($unread_row_archive = $result_unread_archive->fetch_assoc()) {
            $unread_messages_count_archive[$unread_row_archive['task_id']] = $unread_row_archive['unread_count'];
        }
        $stmt_unread_archive->close();

        if ($result_archived->num_rows > 0) {
            while($row_archived = $result_archived->fetch_assoc()) {
                $status_css_class = $status_class_map[$row_archived["status"]] ?? 'unknown_status';

                echo "<div class='table-list-row'><div class='list-row'>";
                echo "<div class='list-cell date'><strong>Жел. срок:</strong><br class='display'> " . ($row_archived["desired_due_date"] ? htmlspecialchars(date('d-m-Y', strtotime($row_archived["desired_due_date"]))) : "Не указан") . "</div>";
                echo "<div class='list-cell date'><strong>Срок исп.:</strong><br class='display'> " . ($row_archived["admin_due_date"] ? htmlspecialchars(date('d-m-Y', strtotime($row_archived["admin_due_date"]))) : "Не указан") . "</div>";
                echo "<div class='list-cell status " . $status_class_map[$row_archived["status"]] ?? 'unknown_status' . "'><strong>Статус:</strong><br class='display'> " . htmlspecialchars($row_archived["status"]) . "</div>";
                echo "<div class='list-cell restaurant'><strong>Ресторан:</strong><br class='display'> " . htmlspecialchars($row_archived["username"] ? $row_archived["username"] : "Неизвестно") . "</div>";
                echo "<div class='list-cell created_at'><strong>Дата создания:</strong><br class='display'> " . htmlspecialchars(date('d-m-Y', strtotime($row_archived["created_at"]))) . "</div>";

                echo "<div class='list-cell actions'>";
                echo "<form action='admin.php' method='post' style='margin:0;'>";
                echo "<input type='hidden' name='task_id' value='" . htmlspecialchars($row_archived['id']) . "'>";
                if ($filter_user_id !== null) {
                    echo "<input type='hidden' name='filter_user' value='" . htmlspecialchars($filter_user_id) . "'>";
                }
                echo "<input type='hidden' name='tab' value='archived-tasks'>";
                echo "<button type='submit' name='restore_task' class='restore-button'>Восстановить</button>";
                echo "</form>";

                $task_id_chat_archive = htmlspecialchars($row_archived['id']);
                $has_new_messages_archive = isset($unread_messages_count_archive[$task_id_chat_archive]) && $unread_messages_count_archive[$task_id_chat_archive] > 0;
                echo "<a href='/chat.php?task_id=" . $task_id_chat_archive . "' class='edit-button chat-button'>";
                echo "Переписка";
                if ($has_new_messages_archive) {
                    echo "<span class='new-message-indicator'></span>";
                }
                echo "</a>";

                echo "<form action='admin.php' method='post' style='margin:0;' onsubmit=\"return confirm('Вы уверены, что хотите безвозвратно удалить эту задачу из архива?');\">";
                echo "<input type='hidden' name='task_id' value='" . htmlspecialchars($row_archived['id']) . "'";
                if ($filter_user_id !== null) {
                    echo "><input type='hidden' name='filter_user' value='" . htmlspecialchars($filter_user_id) . "'";
                }
                echo "<input type='hidden' name='tab' value='archived-tasks'>";
                echo "<button type='submit' name='delete_archived_task' class='delete-archive-button'>Удалить из архива</button>";
                echo "</form>";
                echo "</div>";
                echo "</div>";

                echo "<div class='list-cell description'><strong>Описание задачи:</strong><br> " . nl2br(htmlspecialchars($row_archived["task_description"]));
                if (!empty($row_archived['file_paths'])) {
                    $files_archived = json_decode($row_archived['file_paths'], true);
                    if (is_array($files_archived) && count($files_archived) > 0) {
                        echo "<br><strong>Прикрепленные файлы:</strong><br>";
                        $file_counter_archived = 1;
                        foreach ($files_archived as $file_path_archived) {
                            echo "<a href='/" . htmlspecialchars($file_path_archived) . "' target='_blank'>Файл " . $file_counter_archived . "</a><br>";
                            $file_counter_archived++;
                        }
                    }
                }
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<div class='list-row'><div class='list-cell' style='width: 100%;'>Архив задач для вашего отдела пуст.</div></div>";
        }
        $stmt_archived->close();
        ?>
    </div>
    <?php
    return ob_get_clean();
}

// Проверяем, является ли запрос AJAX-ом
$is_ajax_request = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if ($is_ajax_request) {
    $tab = $_GET['tab'] ?? 'active-tasks'; // Получаем нужную вкладку

    if ($tab === 'active-tasks') {
        echo getAdminActiveTasksHtml($conn, $admin_department, $filter_user_id, $status_class_map);
    } elseif ($tab === 'new-registrations') {
        // Отображаем вкладку "Новые регистрации" только для admingg
        if ($current_username === 'admingg') {
            echo getNewRegistrationsHtml($conn, $filter_user_id);
        } else {
            // Если не admingg, но пытается запросить эту вкладку через AJAX, возвращаем пустой контент или ошибку
            echo "<div class='list-row'><div class='list-cell' style='width: 100%;'>У вас нет прав для просмотра этой вкладки.</div></div>";
        }
    } elseif ($tab === 'archived-tasks') {
        echo getAdminArchivedTasksHtml($conn, $admin_department, $filter_user_id, $status_class_map);
    }
    $conn->close();
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель Администратора - Планер Задач</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Montserrat+Alternates&family=Montserrat:wght@500;600;700&display=swap');
        body {
            font-family: "Montserrat", sans-serif;
            margin: 0;
            background-color: #f4f4f4;
            color: #333;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: #0056b3;
            margin-top: 20px;
            margin-bottom: 15px;
        }
        .table-list-row {
           margin-bottom: 30px;
           border: 1px solid #ddd; /* Внешняя рамка */
           border-radius: 4px;
           box-shadow: 0px 0px 10px 0px rgb(193 193 204 / 59%);
        }
        .admin-header {
            display: block;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            gap: 10px;
        }
        .admin-header p {
            margin: 0;
            font-size: 1.1em;
            font-weight: bold;
            flex-grow: 1;
        }
        .logout-button {
            background-color: #dc3545;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 1em;
            white-space: nowrap;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
        .tasks .list-cell.description,
        .archive-tasks .list-cell.description { /* Добавляем стиль для описания в архиве */
            margin-bottom: 15px;
            margin-top: 10px;
        }

        /* Общие стили для форм и кнопок */
        form {
            margin-bottom: 15px;
        }
        button {
            font-family: "Montserrat", sans-serif;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-right: 5px;
            box-sizing: border-box;
            width: auto;
            min-height: 40px;
        }
        select, input[type="text"] {
            font-family: "Montserrat", sans-serif;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-right: 5px;
            box-sizing: border-box;
            width: 150px;
            min-height: 40px;
        }
        button {
            background-color: #007bff;
            color: white;
            cursor: pointer;
            border: none;
            font-size: 1em;
            margin-top: 5px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .admin-class {
            display: flex;
        }
        .edit-button { /* Стиль для кнопки "Переписка" */
            background-color: #6f42c1; /* Пример цвета */
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none; /* Убираем подчеркивание у ссылки */
            font-size: 1em;
            margin-top: 5px; /* Отступ от других кнопок */
            display: inline-block; /* чтобы отработали margin и padding */
            text-align: center;
        }
        .edit-button:hover {
            background-color: #5931a7;
        }
        .archive-button-admin {
            background-color: #17a2b8; /* Цвет для кнопки "Архивировать" */
            color: white;
        }
        .archive-button-admin:hover {
            background-color: #138496;
        }
        /* --- НАЧАЛО ДОБАВЛЕННЫХ СТИЛЕЙ ДЛЯ АРХИВА --- */
        .restore-button {
            background-color: #28a745; /* Зеленый для восстановления */
            color: white;
        }
        .restore-button:hover {
            background-color: #218838;
        }
        .delete-archive-button {
            background-color: #dc3545; /* Красный для удаления из архива */
            color: white;
        }
        .delete-archive-button:hover {
            background-color: #c82333;
        }
        .clear-all-archive-button {
            background-color: #dc3545; /* Красный для полной очистки */
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1em;
            margin-top: 20px;
        }
        .clear-all-archive-button:hover {
            background-color: #c82333;
        }
        /* --- КОНЕЦ ДОБАВЛЕННЫХ СТИЛЕЙ --- */

        /* Цвета статусов */
        .status-na_uderzhanii { color: #dc3545; font-weight: bold;}
        .status-zadacha_prinyata { color: #ffc107; font-weight: bold;}
        .status-ispolnyaetsya { color: #2637da; font-weight: bold;}
        .status-vypolnena { color: #28a745; font-weight: bold;}

        /* Новые Flexbox-стили для таблиц */
        .list-container {
            display: flex;
            flex-direction: column;
            gap: 1px; /* Разделитель между строками */
            background-color: #fff;
            margin-top: 20px;
            overflow: hidden; /* Для border-radius */
        }
        .list-header, .list-row {
            display: flex;
            flex-wrap: wrap; /* Позволяет элементам переноситься на новую строку на мобильных */
            background-color: #f9f9f9;
            padding: 10px;
            border-bottom: 1px solid #eee; /* Разделитель между строками */
        }
        .list-header {
            font-weight: bold;
            background-color: #f2f2f2;
            padding: 15px 10px;
            border-bottom: 2px solid #ddd;
        }
        .list-header .list-cell {
            padding-top: 0;
            padding-bottom: 0;
        }
        .list-row:last-child {
            border-bottom: none; /* Убираем нижнюю границу у последней строки */
        }

        .list-cell {
            flex: 1; /* Все ячейки занимают равное пространство по умолчанию */
            padding: 5px 10px;
            min-width: 16%; /* Минимальная ширина для ячеек */
            box-sizing: border-box;
            word-break: break-word; /* Перенос длинных слов */
        }
        /* Специфические ширины для колонок в активных задачах (для десктопа) */
        .tasks .list-cell.description { flex: 2; }
        .tasks .list-cell.date { flex: 0 0 10%; width: 16%; }
        .tasks .list-cell.status { flex: 0 0 12%; width: 16%; }
        .tasks .list-cell.restaurant { flex: 0 0 15%; width: 16%; }
        .tasks .list-cell.actions { flex: 0 0 15%; width: 16%; }

        /* Специфические ширины для колонок в новых регистрациях и архиве */
        .users .list-cell.id, .archive-tasks .list-cell.id { flex: 0 0 10%; width: 16%; }
        .users .list-cell.username, .archive-tasks .list-cell.username { flex: 1; }
        .users .list-cell.created_at, .archive-tasks .list-cell.created_at { flex: 0 0 20%; width: 20%; }
        .users .list-cell.actions, .archive-tasks .list-cell.actions { flex: 0 0 25%; width: 25%; }

        /* Специальные ширины для ячеек архива */
        .archive-tasks .list-cell.date { flex: 0 0 16%; width: 16%; }
        .archive-tasks .list-cell.status { flex: 0 0 12%; width: 16%; }
        .archive-tasks .list-cell.restaurant { flex: 0 0 15%; width: 16%; }
        .archive-tasks .list-cell.actions { flex: 0 0 20%; width: 20%; }


        /* Стили для действий с задачей/пользователем внутри ячейки */
        .list-cell.actions {
            display: flex;
            flex-direction: column;
            gap: 5px;
            padding: 5px; /* Уменьшаем паддинг для кнопок */
        }
        .list-cell.actions form {
            margin: 0;
            display: flex; /* Чтобы кнопки в форме могли быть строчными */
            gap: 5px; /* Отступ между кнопками в одной форме */
            flex-wrap: wrap; /* Если кнопок много, пусть переносятся */
        }
        .list-cell.actions button,
        .list-cell.actions .edit-button { /* Добавляем edit-button сюда */
            font-family: "Montserrat", sans-serif;
            width: auto; /* Позволяет кнопкам быть гибкими */
            flex-grow: 1; /* Растягиваться при необходимости */
            margin-top: 0;
            white-space: nowrap; /* Предотвращает перенос текста кнопки */
            font-size: 0.9em;
            padding: 6px 10px;
        }
        .list-cell.actions input[type="text"],
        .list-cell.actions select {
            width: 100%;
            margin-right: 0;
            margin-bottom: 5px;
        }

        /* Дополнительные стили для чекбокса "Сделать администратором" */
        .list-cell.actions form label {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.9em;
            white-space: nowrap;
            margin-bottom: 5px; /* Отступ от кнопки */
            padding-left: 0px; /* Убираем лишний отступ */
        }
        .list-cell.actions form label input[type="checkbox"] {
            width: auto;
            min-height: auto;
            margin: 0;
            cursor: pointer;
        }

        /* Стили для Datepicker */
        .ui-datepicker {
            width: 300px;
            font-size: 1.1em;
            z-index: 1000 !important; /* Убедимся, что datepicker поверх всего */
        }
        .ui-datepicker table {
            width: 100%;
            min-width: unset;
        }
        .ui-datepicker td span, .ui-datepicker td a {
            padding: 0.5em;
            text-align: center;
        }
        /* Убешимся, что календарь не выходит за пределы экрана на маленьких устройствах */
        @media (max-width: 768px) {
            .ui-datepicker {
                width: 95% !important;
                left: 2.5% !important;
                font-size: 1em;
            }
        }

        /* Медиа-запросы для мобильных устройств */
         @media (max-width: 1232px) {
             .tasks .list-cell.description,
             .archive-tasks .list-cell.description {
                flex: 2;
                padding: 10px !important;
            }
             .display {
                display: none;
            }
            .list-header, .list-row {
                display: block;
            }
            .list-cell {
                width: 100% !important; /* Каждая ячейка занимает всю ширину */
                padding: 5px 0;
                border-bottom: 1px dashed #eee; /* Разделитель между полями */
                flex: none; /* Убираем flex-grow для мобильных */
                max-width: none;
                min-width: unset;
            }
         }
        @media (max-width: 768px) {
            .display {
                display: none;
            }
            .container {
                margin: 10px;
                padding: 15px;
            }
            .admin-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .admin-header p {
                margin-bottom: 10px;
            }
            .admin-class {
               display: block;
            }
            .logout-button {
                display: block;
                width: 90%;
                margin: 0 auto;
                text-align: center;
            }
            h1, h2 {
                font-size: 1.5em;
                text-align: center;
            }
            p {
                font-size: 0.9em;
            }

            .list-header {
                display: none; /* Скрываем заголовки столбцов на мобильных */
            }
            .list-row {
                flex-direction: column; /* Элементы в столбец */
                align-items: flex-start;
                padding: 10px;
                border: 1px solid #ddd;
                margin-bottom: 10px;
                border-radius: 4px;
            }
            .list-container {
                border: none; /* Убираем внешнюю рамку для мобильных */
                background-color: transparent;
                gap: 0;
            }

            .list-cell {
                width: 100% !important; /* Каждая ячейка занимает всю ширину */
                padding: 5px 0;
                border-bottom: 1px dashed #eee; /* Разделитель между полями */
                flex: none; /* Убираем flex-grow для мобильных */
                max-width: none;
                min-width: unset;
            }
            .list-cell:last-of-type {
                border-bottom: none;
            }
            .list-cell strong {
                display: inline-block; /* Для заголовков полей в мобильной версии */
                min-width: 120px; /* Минимальная ширина для заголовка, чтобы выровнять значения */
                margin-right: 5px;
                font-size: 0.9em; /* Уменьшаем размер текста заголовка */
            }

            /* Действия внутри ячейки - мобильные */
            .list-cell.actions {
                flex-direction: column; /* Кнопки в столбец */
                align-items: stretch;
                padding: 10px 0;
                border-top: 1px solid #eee; /* Разделитель сверху */
                border-bottom: none;
                margin-top: 5px;
            }
            .list-cell.actions button,
            .list-cell.actions .edit-button { /* Добавляем edit-button сюда */
                width: 100% !important; /* Кнопки занимают всю ширину */
                margin-bottom: 5px; /* Отступ между кнопками */
                font-size: 0.9em;
                padding: 8px 10px;
            }
            .list-cell.actions button:last-child {
                margin-bottom: 0;
            }
            .list-cell.actions form {
                flex-direction: column;
                gap: 5px;
            }
            .list-cell.actions form label {
                width: 100%;
                margin-bottom: 5px;
            }
        }

        /* Медиа-запросы для планшетов (больше 768px, но меньше 1024px) */
        @media (min-width: 769px) and (max-width: 1024px) {
            .container {
                padding: 25px;
            }
            h1 {
                font-size: 2.2em;
            }
            h2 {
                font-size: 1.8em;
            }
            .list-cell {
                padding: 12px 10px;
                font-size: 0.95em;
            }
            .list-cell.actions {
                flex-direction: row; /* На планшетах кнопки могут быть в строку */
                flex-wrap: wrap;
                justify-content: flex-start;
                padding: 8px 10px;
            }
            .list-cell.actions button,
            .list-cell.actions .edit-button { /* Добавляем edit-button сюда */
                flex: 1 1 auto;
                min-width: 80px;
            }
            .list-cell.actions form label {
                flex: 1 1 100%; /* Чекбокс на новой строке, занимает всю ширину */
                margin-bottom: 5px;
            }
        }

        /* Стили для вкладок (скопированы из index.php) */
        .new-message-indicator {
            position: absolute;
            top: 5px;
            right: 5px;
            width: 10px;
            height: 10px;
            background-color: red;
            border-radius: 50%;
            display: block;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.5);
        }
        .chat-button {
            position: relative;
        }

        .tabs-container {
            margin-top: 20px;
        }
        .tab-buttons {
            display: flex;
            border-bottom: 2px solid #ddd;
            margin-bottom: 20px;
        }
        .tab-button {
            background-color: #f2f2f2;
            border: 1px solid #ddd;
            border-bottom: none;
            padding: 10px 20px;
            cursor: pointer;
            font-weight: bold;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            margin-right: 5px;
            transition: background-color 0.3s ease;
        }
        .tab-button:hover {
            background-color: #e0e0e0;
        }
        .tab-button.active {
            background-color: #fff;
            border-bottom: 2px solid #fff;
            position: relative;
            z-index: 1;
        }
        .tab-content .tab-pane {
            display: none;
            padding: 20px 0;
            border-top: none;
        }
        .tab-content .tab-pane.active {
            display: block;
        }

        @media (max-width: 768px) {
            .tab-buttons {
                flex-direction: column;
            }
            .tab-button {
                margin-right: 0;
                margin-bottom: 5px;
                border-bottom: 1px solid #ddd;
                border-radius: 4px;
            }
            .tab-button.active {
                border-bottom: 1px solid #ddd;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="admin-header">
            <h1>GG - <?php echo htmlspecialchars($admin_department); ?></h1>
            <div class='admin-class'>
            <p>Вы вошли как: <?php echo htmlspecialchars($current_username); ?> </p>
            <a href="?logout" class="logout-button">Выйти</a>
            </div>
        </div>
        <p>Управляйте задачами, изменяйте статусы, устанавливайте сроки и архивируйте выполненные задачи. Подтверждайте регистрацию новых пользователей</p>

        <hr>
        <?php echo $message; // Выводим сообщение здесь ?>

        <div class="tabs-container">
            <div class="tab-buttons">
                <button class="tab-button active" data-tab="active-tasks">Активные задачи</button>
                <?php if ($current_username === 'admingg'): // Показываем вкладку только для admingg ?>
                    <button class="tab-button" data-tab="new-registrations">Новые регистрации</button>
                <?php endif; ?>
                <button class="tab-button" data-tab="archived-tasks">Архив задач</button>
            </div>

            <div class="tab-content">
                <div id="active-tasks" class="tab-pane active">
                    <?php
                        $initial_filter_user_id = $_GET['filter_user'] ?? null;
                        echo getAdminActiveTasksHtml($conn, $admin_department, $initial_filter_user_id, $status_class_map);
                    ?>
                </div>

                <div id="new-registrations" class="tab-pane">
                    <?php
                        // Отображаем содержимое вкладки "Новые регистрации" только для admingg
                        if ($current_username === 'admingg') {
                            echo getNewRegistrationsHtml($conn, $filter_user_id);
                        } else {
                            echo "<div class='list-row'><div class='list-cell' style='width: 100%;'>У вас нет прав для просмотра этой вкладки.</div></div>";
                        }
                    ?>
                </div>

                <div id="archived-tasks" class="tab-pane">
                    <?php
                        echo getAdminArchivedTasksHtml($conn, $admin_department, $filter_user_id, $status_class_map);
                    ?>
                </div>
            </div>
        </div>

    </div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.13.2/i18n/jquery-ui-i18n.min.js"></script>
<script>
$( function() {
    // Устанавливаем русскую локализацию для Datepicker
    $.datepicker.setDefaults( $.datepicker.regional[ "ru" ] );

    // Функция для инициализации Datepicker
    function initializeDatepickers() {
        $( ".datepicker" ).datepicker({
            dateFormat: "dd-mm-yy",
            firstDay: 1,
            dayNamesMin: [ "Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб" ],
            monthNames: [ "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь" ],
            showButtonPanel: true,
            closeText: 'Готово',
            currentText: 'Сегодня',
            beforeShow: function(input, inst) {
                if ($(window).width() <= 768) {
                    setTimeout(function() {
                        var inputOffset = $(input).offset();
                        var inputWidth = $(input).outerWidth();
                        var datepickerWidth = $(inst.dpDiv).outerWidth();
                        var leftPos = (inputOffset.left + inputWidth / 2) - (datepickerWidth / 2);

                        if (leftPos < 0) {
                            leftPos = 0;
                        }
                        if (leftPos + datepickerWidth > $(window).width()) {
                            leftPos = $(window).width() - datepickerWidth;
                        }

                        $(inst.dpDiv).css({
                            top: inputOffset.top + $(input).outerHeight() + 5,
                            left: leftPos
                        });
                    }, 0);
                } else {
                     setTimeout(function() {
                        $(inst.dpDiv).css({
                            top: $(input).offset().top + $(input).outerHeight() + 5,
                            left: $(input).offset().left
                        });
                    }, 0);
                }
            }
        });
    }

    // Инициализируем Datepicker при первой загрузке страницы
    initializeDatepickers();

    const tabButtons = document.querySelectorAll('.tab-button');
    const tabPanes = document.querySelectorAll('.tab-pane');
    const activeTasksPane = document.getElementById('active-tasks');
    const newRegistrationsPane = document.getElementById('new-registrations');
    const archivedTasksPane = document.getElementById('archived-tasks');

    // Функция для загрузки содержимого вкладки по AJAX
    async function loadTabContent(tabName, params = {}) {
        const urlParams = new URLSearchParams(params);
        urlParams.set('tab', tabName);
        urlParams.set('is_ajax', '1');
        const url = `admin.php?${urlParams.toString()}`;

        try {
            const response = await fetch(url, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const html = await response.text();
            if (tabName === 'active-tasks') {
                activeTasksPane.innerHTML = html;
            } else if (tabName === 'new-registrations') {
                newRegistrationsPane.innerHTML = html;
            } else if (tabName === 'archived-tasks') {
                archivedTasksPane.innerHTML = html;
            }
            // Переинициализируем Datepicker для нового содержимого
            initializeDatepickers();
            // Обновляем обработчики для фильтра, если это вкладка активных задач
            attachFilterListenerToActiveTasks();
            fetchUnreadMessages(); // Обновляем индикаторы сообщений
        } catch (error) {
            console.error('Ошибка загрузки содержимого вкладки:', error);
        }
    }

    // Функция для прикрепления обработчика событий к фильтру активных задач
    function attachFilterListenerToActiveTasks() {
        const filterUserSelect = document.querySelector('#active-tasks #filter_user');
        if (filterUserSelect) {
            filterUserSelect.onchange = function() {
                const selectedUserId = this.value;
                loadTabContent('active-tasks', { filter_user: selectedUserId });
            };
        }
        // Обработчик для кнопки "Применить"
        const filterForm = document.querySelector('#active-tasks form[action="admin.php"][method="get"]');
        if (filterForm) {
            filterForm.onsubmit = function(event) {
                event.preventDefault(); // Предотвращаем стандартную отправку формы
                const selectedUserId = filterUserSelect ? filterUserSelect.value : '';
                loadTabContent('active-tasks', { filter_user: selectedUserId });
            };
        }
    }

    // Инициализация вкладок при загрузке страницы
    function initializeTabs() {
        const urlParams = new URLSearchParams(window.location.search);
        const initialTab = urlParams.get('tab') || 'active-tasks';

        tabButtons.forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.tab === initialTab) {
                btn.classList.add('active');
            }
        });
        tabPanes.forEach(pane => {
            pane.classList.remove('active');
            if (pane.id === initialTab) {
                pane.classList.add('active');
            }
        });

        // Загружаем содержимое активной вкладки (если она не активна по умолчанию)
        // Если активная вкладка уже загружена (например, 'active-tasks' при первой загрузке),
        // то AJAX запрос не нужен, но нужно прикрепить слушатели.
        if (initialTab !== 'active-tasks' || !activeTasksPane.classList.contains('active')) {
             let params = {};
             // Если переключаемся на активные задачи, сохраняем текущий фильтр пользователя, если он есть
             if (initialTab === 'active-tasks' && urlParams.has('filter_user')) {
                 params['filter_user'] = urlParams.get('filter_user');
             }
             loadTabContent(initialTab, params);
        }
        // В любом случае, прикрепляем слушатель для активных задач, так как он может быть динамически добавлен
        attachFilterListenerToActiveTasks();
    }


    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.dataset.tab;

            // Если это вкладка "Новые регистрации" и текущий пользователь не "admingg",
            // просто не переключаемся на нее и ничего не делаем.
            if (targetTab === 'new-registrations' && '<?php echo $current_username; ?>' !== 'admingg') {
                return;
            }

            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabPanes.forEach(pane => pane.classList.remove('active'));

            document.getElementById(targetTab).classList.add('active');
            button.classList.add('active');

            const url = new URL(window.location.href);
            url.searchParams.set('tab', targetTab);
            // Очищаем специфичные для вкладок параметры при переключении
            if (targetTab !== 'active-tasks') {
                url.searchParams.delete('filter_user');
            }
            history.pushState(null, '', url.toString());

            // Загружаем контент для выбранной вкладки
            let params = {};
            if (targetTab === 'active-tasks') {
                // При переключении на активные задачи, сбрасываем фильтр пользователя
                params['filter_user'] = '';
            }
            loadTabContent(targetTab, params);
        });
    });

    initializeTabs();

    // --- КОД ДЛЯ ОНЛАЙН УВЕДОМЛЕНИЙ (скопирован из index.php) ---
    const NEW_MESSAGE_INDICATOR_CLASS = 'new-message-indicator'; // Класс индикатора

    async function fetchUnreadMessages() {
        try {
            const response = await fetch('admin_check_new_messages.php', { // Будем использовать новый файл для админа
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const unreadCounts = await response.json(); // Парсим JSON ответ

            // Проходимся по всем кнопкам чата на странице
            document.querySelectorAll('.chat-button').forEach(button => {
                const taskIdMatch = button.href.match(/task_id=(\d+)/); // Извлекаем task_id из href
                if (taskIdMatch && taskIdMatch[1]) {
                    const currentTaskId = taskIdMatch[1];
                    let indicator = button.querySelector('.' + NEW_MESSAGE_INDICATOR_CLASS);

                    if (unreadCounts[currentTaskId] && unreadCounts[currentTaskId] > 0) {
                        // Если есть непрочитанные сообщения для этой задачи, показываем индикатор
                        if (!indicator) {
                            indicator = document.createElement('span');
                            indicator.classList.add(NEW_MESSAGE_INDICATOR_CLASS);
                            button.appendChild(indicator);
                        }
                    } else {
                        // Если нет непрочитанных сообщений, удаляем индикатор
                        if (indicator) {
                            indicator.remove();
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Ошибка при получении непрочитанных сообщений:', error);
        }
    }

    // Вызываем функцию при загрузке страницы
    fetchUnreadMessages();

    // Запускаем периодическую проверку каждые 10 секунд (10000 миллисекунд)
    setInterval(fetchUnreadMessages, 10000);
    // --- КОНЕЦ КОДА ОНЛАЙН УВЕДОМЛЕНИЙ ---
});
</script>
</body>
</html>