<?php
session_start();
require_once 'db_connect.php'; // Убедитесь, что путь к файлу корректен

header('Content-Type: application/json'); // Указываем, что ответ будет в формате JSON

$unread_messages_count = [];

// Проверяем, авторизован ли пользователь и является ли он администратором
if (!isset($_SESSION['user_id']) || !$_SESSION['is_admin']) {
    echo json_encode([]); // Если не авторизован, возвращаем пустой массив
    exit();
}

$admin_department = $_SESSION['department'] ?? null;

if ($admin_department === null) {
    // Если отдел администратора не установлен в сессии, получаем его из БД
    $stmt_department = $conn->prepare("SELECT department FROM users WHERE id = ?");
    $stmt_department->bind_param("i", $_SESSION['user_id']);
    $stmt_department->execute();
    $result_department = $stmt_department->get_result();
    if ($row_department = $result_department->fetch_assoc()) {
        $_SESSION['department'] = $row_department['department'];
        $admin_department = $row_department['department'];
    }
    $stmt_department->close();
}


if ($admin_department) {
    $stmt_unread = $conn->prepare("
        SELECT tm.task_id, COUNT(tm.id) AS unread_count FROM task_messages tm
        JOIN users sender ON tm.sender_id = sender.id
        JOIN tasks t ON tm.task_id = t.id
        WHERE tm.is_read = 0
        AND sender.is_admin = 0 /* Сообщения от НЕ-админов */
        AND t.department = ?
        GROUP BY tm.task_id
    ");
    $stmt_unread->bind_param("s", $admin_department);
    $stmt_unread->execute();
    $result_unread = $stmt_unread->get_result();
    while ($unread_row = $result_unread->fetch_assoc()) {
        $unread_messages_count[$unread_row['task_id']] = $unread_row['unread_count'];
    }
    $stmt_unread->close();
}

$conn->close();

echo json_encode($unread_messages_count); // Возвращаем данные в формате JSON
?>