<?php
// Начинаем сессию PHP. Это должно быть самой первой строкой в файле!
session_start();

require_once 'db_connect.php'; // Подключаем файл с подключением к БД

$message = ''; // Переменная для сообщений пользователю

// Если пользователь уже авторизован, перенаправляем его
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['is_admin']) {
        header("Location: admin.php");
    } else {
        header("Location: /");
    }
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Простая валидация
    if (empty($username) || empty($password)) {
        $message = "<p style='color: red;'>Пожалуйста, введите имя пользователя и пароль.</p>";
    } else {
        // Подготавливаем запрос для получения данных пользователя
        // ИСПРАВЛЕНИЕ: Добавлено is_confirmed в SELECT
        $stmt = $conn->prepare("SELECT id, username, password_hash, is_admin, is_confirmed FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            // Проверяем введенный пароль с хешированным паролем из БД
            if (password_verify($password, $user['password_hash'])) {
                // Проверяем, подтвержден ли пользователь
                if (!$user['is_confirmed']) { // Теперь $user['is_confirmed'] будет существовать
                    $message = "<p style='color: red;'>Ваша учетная запись ожидает подтверждения администратором.</p>";
                } else {
                    // Пароль верный и пользователь подтвержден, создаем сессию
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['is_admin'] = (bool)$user['is_admin'];
                    $_SESSION['department'] = $user['department'];

                    // Перенаправляем пользователя в зависимости от его роли
                    if ($_SESSION['is_admin']) {
                        header("Location: admin.php");
                    } else {
                        header("Location: index.php");
                    }
                    exit(); // Важно завершить выполнение скрипта после редиректа
                }
            } else {
                $message = "<p style='color: red;'>Неверное имя пользователя или пароль.</p>";
            }
        } else {
            // Если пользователя с таким именем нет
            $message = "<p style='color: red;'>Неверное имя пользователя или пароль.</p>";
        }
        $stmt->close();
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход - Планер Задач</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 400px;
            background-color: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #0056b3;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            text-align: left;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 15px;
            font-size: 0.9em;
        }
        .register-link {
            margin-top: 20px;
            display: block;
        }
        .register-link a {
            color: #007bff;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Вход</h1>
        <?php echo $message; ?>
        <form action="admin_login.php" method="post">
            <label for="username">Имя пользователя:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Войти</button>
        </form>
        <span class="register-link">Нет аккаунта? <a href="register.php">Зарегистрироваться</a></span>
    </div>
</body>
</html>